# EvidenceOps Corpora Review and Upgrade Plan

This package contains:
- `option_a_current_review.csv` — review of the current public corpus selection
- `option_a_v2_canonical_manifest.csv` — recommended public corpus v2 manifest
- `option_b_v2_relational_manifest.csv` — relational metadata for the current synthetic corpus
- `option_b_storylines.csv` — storyline-level eval/gold set starter specification
- `option_b_upgrade_backlog.md` — concrete changes to move the synthetic corpus closer to 10/10

## Fast take
- **Option A** should be the main real-world benchmark corpus.
- **Option B** should be the main demo and controlled-evals corpus.
- The fastest improvement is metadata, lineage, and storyline scaffolding.
- The most important content fix is a timeline clarification in Option B and explicit annotation/replacement of weak links in Option A.

## Design principle
Do not force both corpora to do the same job:
- Option A wins on external credibility and benchmark realism.
- Option B wins on controllability, narrative coherence, and gold-set generation.
